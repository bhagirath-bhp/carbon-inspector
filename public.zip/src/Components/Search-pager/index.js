import React, { useState } from 'react'
import "./styles.css";
import data from "../../Resources/data.json"

function findmatches(wordtomatch, items){
  return items.filter(ddata => {
    const regex = new RegExp(wordtomatch, "gi");
    return (ddata.Company.match(regex) || ddata.ProductNameFunctionalUnit.match(regex));
    // console.log(ddata.ProductNameFunctionalUnit.match(regex));
  })
}
let items = [];
let [inputVal, setInputVal] = ("");
let filteredItems = [];
let fliteredHtml = [];
function displayMatches(){
  // console.log(this);
  findmatches(inputVal, items)
}

function Searchpager() {
  let dataurl = "../../Resources/data.json";
  items = data;
  items = Object.entries(items);
  // console.log(findmatches('hi', items[0][1]))
  

  return (
    <>
        <div className="searchpager">
            <form className="search">
                <p>search</p>
                <input type="text" name="search" id="search" onKeyUpCapture={event => {setInputVal(event.target.value)}}/>
            </form>
            <div className="suggestions-tab">
              <p>suggestion</p>
              <ul className='suggestions'>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
                <li>
                  <span>Name</span>
                  <span>email</span>
                  <span>category</span>
                </li>
              </ul>
            </div>
        </div>
    </>
  )
  
}

export default Searchpager