import React from 'react';
import Homepage from './Pages/Homepage';
import './App.css';
import Companyprofile from './Pages/Companyprofile';
import Compareprofile from './Pages/Compareprofile';

function App() {
  return (
    <div className='App'>
      <Homepage/>
      {/* <Companyprofile/> */}
      {/* <Compareprofile/> */}
    </div>
  )
}

export default App;
